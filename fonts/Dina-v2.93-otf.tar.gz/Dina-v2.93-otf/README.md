# Dina as an .odf

This embeds the Dina bitmaps in a vector font format, so that they will display
on Linux distros using Pango v1.44 and newer (eg. Ubuntu "Focal" 20.04).

This does not convert the bitmaps to vector outlines. They are just repackaged.

This works, with all defined font sizes, with bold and italic.

# Installing

On Ubuntu, I install these files by

1. Copying them to ~/.fonts/Dina,
2. Enable bitmap fonts:

    (
        cd /etc/fonts/conf.d
        sudo rm -f 70-no-bitmaps.conf
        sudo ln -sf ../conf.avail/70-yes-bitmaps.conf
    )

3. Rebuild the cache:

    fc-cache -r -v | grep --color '[Dd]ina'

4. Set as default monospaced font:

    gsettings set org.gnome.desktop.interface monospace-font-name "Dina 10"

# Known problems

* For reasons unknown, even though Dina renders in gnome-terminal,
  it appears invisible in font selection dialogs, so you've got to
  click around blindly to select it.
  (the gnome-terminal selector is marginally better than the Tweaks one,
  since the preview actually works, showing you what you'll get.)
* Pressing ctrl+ and ctrl- in gnome-terminal only cycles through three of the
  four possible font sizes. I don't understand why. But all four regular sizes
  are available if you select the size explicitly from a font selector.
* Selecting a non-existent size in gnome-terminal displays a blank window,
  rather than falling back to some other font.

# How these files were generated

Generated from the v2.93 Dina?.fon files, using FontForge,
following the instructions here:
https://gitlab.gnome.org/GNOME/pango/issues/386#note_570411

